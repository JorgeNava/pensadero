# https://www.python.org/dev/peps/pep-0396/
__version__ = '0.6.0'
